# Chappy Storage Compressor R2.6 — 置換直前の改変・同一内容の実体差し替えを検出

**Windows C# / WPF ソース試作版 — 実機未検証。原本の写真・動画で使用しないでください。**

### R2.6の変更点

- テスト専用 `SyntheticReplacementExperiment` の `File.Replace` 直前に **stage / externalバックアップ**を再検証するよう修正。以前は初回コピー後に改変されても置換されうる経路がありました。
- 検証前後のNTFSファイルID・メタデータ・リンク数を照合して、SHA-256が同じでもファイル実体のすり替えを検出するよう改善。
- Windowsの合成 `.bin` テスト4種類を追加（候補の直前改変、バックアップ直前改変、候補の新規ハードリンク、同内容での実体差し替え）。通常版にはテスト用置換エンジンを含めません。
- 独立したPython参考検証と静的契約チェック、Windows診断バッチとCIへの登録、ロードマップ更新。

### 今回の検証範囲

ソース契約検査 **27/27 PASS**、参考ファイルシステム検証 **10/10 PASS**。**Windows .NET 10のC#ビルド、NTFS実行テスト、実際の空き容量回復は未実施**です。Python検証はC#の実行結果を証明しません。

Windowsで `RUN_DIAGNOSTICS.bat` を実行し、`diagnostics/RESULT.txt` / `build.log` / `smoke-tests.log` を確認してください。**これはまだ個人データを変更する許可ではありません。** 詳細は `docs/R26_TEST_PLAN.md` / `docs/ROADMAP_STATUS.md` を参照。

---

# Chappy Storage Compressor R2.5 — rollback artifact identity hardening

**2026-11-14 / Windows C# WPF source prototype / NEVER process personal original media**

R2.5 strengthens the isolated synthetic recovery experiment from R2.4. Before trusting any test-only rollback source, backup, staging artifact or journal, the code now rejects files that are not ordinary standalone files (including shared hardlinks, reparse points, unsafe attributes and NTFS alternate data streams). Active rollback journals have a bounded size. The R2.5 Windows smoke suite covers shared backup, journal, rollback, temporary journal, an oversized journal and a stage with an extra named stream. The smoke entry point now refuses a non-NTFS TEMP volume.

- **NEW:** `tools/r25_contract_check.py` — 25/25 source-structure checks passed; not a compiler.
- **NEW:** `tools/r25_reference_check.py` — 10/10 Python filesystem model checks passed; not NTFS/C# proof.
- **UPDATED:** `RUN_DIAGNOSTICS.bat`, Windows CI workflow, `.csproj` targeting and package builder.
- **NOT DONE:** Windows .NET 10 build, C# NTFS tests, physical backup tests and real capacity recovery.
- **STILL DISABLED:** hardlink consolidation and original media replacement in the normal app. No automatic commit or deletion of user originals.

Run `RUN_DIAGNOSTICS.bat` on Windows with the .NET 10 SDK using only the generated synthetic test fixtures. Save the diagnostic logs; `PASS` is not permission to modify precious originals. See `docs/ROADMAP_STATUS.md` and `docs/R25_TEST_PLAN.md`.

---

# Chappy Storage Compressor R2.4 — interrupted preparation cleanup (synthetic only)

**2026-11-14 / Windows C# WPF source prototype / NEVER use on original personal media**

## What's new in R2.4

- Fix the **pre-journal crash blind spot** found during R2.3 review: after the external-copy / stage-copy / pending-journal-temp fault checkpoints, the synthetic experiment can now **inspect** the leftovers and **discard only verified preparation artifacts**. A SHA mismatch, missing backup, shared hardlink, reserved-name collisions, unsafe attributes or ambiguous rollback state triggers **manual-review refusal** instead of automatic deletion.
- Fix **orphaned external-copy files after a successful rollback**: the transaction journal is removed first, then the verified synthetic external copy is cleaned. A new fault checkpoint between these operations makes that boundary testable.
- Add a checkpoint between journal-temp flushing and renaming; simulate last-moment source mutation and refuse `File.Replace` when the source snapshot changes.
- Add Windows test-only cases for **full original-file snapshot restoration** (identity, timestamps, file attributes, security descriptor), modified preparation, lost last-journal write, source races and an **NTFS named stream** refusal.
- Add **13 independent Python reference checks** and **25 static source-contract checks**; improve `RUN_DIAGNOSTICS.bat` and Windows GitHub Actions to preserve logs even when a smoke test fails.

**Safety boundary:** `SyntheticReplacementExperiment.cs` remains under `#if CHAPPY_TESTING`; the production application has no code path to invoke it. This is still an experiment using isolated generated `.bin` fixtures under a uniquely named TEMP directory with a sentinel. **No JPG/PNG/MP4 original replacement, successful dedupe, physical backup or real capacity recovery is enabled.** The independent Python model does not prove Windows NTFS semantics. Windows .NET 10 compilation and NTFS smoke tests are still **NOT RUN** in the authoring environment.

## Windows verification

1. Extract the ZIP into an unprotected folder; install .NET 10 SDK.
2. Run `RUN_DIAGNOSTICS.bat` (this creates synthetic test files inside Windows TEMP only).
3. Share or inspect `diagnostics/RESULT.txt`, `diagnostics/build.log`, `diagnostics/smoke-tests.log`, and `diagnostics/publish.log` for failures. `RESULT.txt = PASS` is an engineering test milestone, **not permission to process irreplaceable media**.
4. Optional: push the sources to a private GitHub repository and run `.github/workflows/build-windows.yml`; this workflow is included but has **not** been run for this R2.4 snapshot. The diagnostic logs are uploaded even on failure.

Progress and outstanding gates: `docs/ROADMAP_STATUS.md` and `docs/R24_TEST_PLAN.md`.

---

# Chappy Storage Compressor R2.3 — テスト専用・原本置換復旧実験

**2026-11-14 / Windows C# WPF ソース試験版 / 本番原本への置換・重複統合は引き続き無効**

## R2.3で追加した内容

- `Core/SyntheticReplacementExperiment.cs`：`#if CHAPPY_TESTING` だけでコンパイルされる、**合成 `.bin` ファイル専用の置換・復旧実験**。通常版には実装を含めず、GUIからも操作できません。
- 操作対象をWindowsの独立したTEMPテストフォルダに限定。テスト専用マーカー必須、ジャンクション・共有ハードリンク・代替データストリーム・使用中ファイル・原本更新を拒否。
- 原本のコピーと候補をSHA-256で照合 → 保存先へフラッシュ → ジャーナルを同期書き込み → `File.Replace` による**テストファイル限定**の切替 → 原本のバックアップを使うロールバック、という経路を追加。
- 6つの合成停止地点からの復旧、正常ロールバック、改ざんされたバックアップ、使用中ファイル、ハードリンク、テスト領域外への操作拒否について、Windowsで実行するC#スモークテストを追加。
- 独立Python参考テストは **7/7合格**、R2.3専用静的契約チェックは **20/20合格**。**C#コンパイル・Windows NTFS実行は未実施**。

### 重要な制限

- **本番画像の圧縮・置換は追加していません。容量回復量は依然0Bです。** `Begin` 実験は必ず `RollBack` で原本に戻し、自動コミット／旧データ削除を用意していません。
- テストでは外部バックアップ領域を同一ドライブ上の別フォルダで模擬しています。**物理的に独立したバックアップではなく、ディスク障害の保護は証明しません。**
- 原子的切替・フラッシュはOS側で実装していますが、停電復旧・ACL/作成日時/名前付きストリーム・Concurrent Writer・ファイルシステムジャーナルの完全性は実機試験で未確認。`File.Replace` の成功は画像の無劣化同等性の証明ではありません。
- Pythonの参考モデルはWindowsの`File.Replace`とは異なる2段階renameを使用した合成状態検査です。C#が動作する証拠として扱いません。
- **R2.3を実際の写真・動画に適用しないでください。** テスト専用コードも試験用フォルダ以外には使用できない設計です。

### Windowsでの検証方法

Windows 10/11＋.NET 10 SDKで `RUN_DIAGNOSTICS.bat` を実行。`diagnostics/RESULT.txt`、`build.log`、`smoke-tests.log` を確認してください。新しいR2.3テストは `tests/Program.cs` の `TestR23SyntheticReplacement` で、生成したランダム `.bin` だけを使用します。実機の検証結果は本キットには入っていません。

詳細：`docs/R23_TEST_PLAN.md` および `docs/ROADMAP_STATUS.md`。

---

# Chappy Storage Compressor R2.2 — 容量回復の事前安全診断

**2026-11-14 / Windows C# WPF ソース試験版 / 本番原本の変更は禁止**

## R2.2で追加したもの

- **容量回復の読み取り専用事前診断**：PNG/JPGの再検証済み圧縮候補に対し、元ディスクに候補を置くための空きと、別ボリュームに原本を退避するための空きがあるか調べます。両方に追加の64MiB余裕を要求します。
- **安全属性の確認**：元ファイルのNTFS情報、リンク数、代替データストリーム、再解析ポイント、原本サイズ変更を検査。ハードリンク済みファイルは対象外。
- **GUI追加**：「容量回復の事前安全診断」から候補の記録フォルダとバックアップ用フォルダを選び、保留理由と見込みを表示。**何も変更・削除しません。**
- **診断テスト**：純粋な容量計算のC#合成試験を追加。独立Python参考テスト10/10合格（C#自体は未実行）。

**重要な限界：** この機能の「条件合格」は空き容量・ファイル属性の予備判定にすぎず、画素・メタデータの置換直前再検証、独立バックアップの実物確認、ACL復元、原子性、停電復旧の安全性を保証しません。**元ファイルを置換する機能は未実装・無効で、実際の容量回復は0Bのままです。** 別ドライブ文字であっても同じ物理ディスクかもしれません。

Windowsでは `.NET 10 SDK` を導入し `RUN_DIAGNOSTICS.bat` を実行してください（必ずテスト専用データ）。`docs/R22_TEST_PLAN.md` と `docs/ROADMAP_STATUS.md` に今回の検証状況と次の課題を記録しています。

---

# Chappy Storage Compressor R2.1 — 重複排除と無劣化候補の二重計上防止

**2026-11-14更新 / Windows向け C# WPF ソース試験版 / 原本変更は禁止**

## R2.1で実装したもの

- **重複とPNG/JPG候補の削減見込みの重なり分析**：最初に読み取り専用の完全一致スキャンを実行し、同じ親フォルダのPNG/JPG統合容量レポートを開くと、重複側と圧縮候補側の理論節約量が重複している部分を分けて表示します。
- **古いスキャンへの安全対策**：重複グループの各ファイルに対し、属性・日時・ファイルID・SHA-256を再検証。不一致のグループは計上しません。
- **診断バッチを追加**：`RUN_DIAGNOSTICS.bat` によりビルド・隔離テスト・EXE生成のログを `diagnostics` フォルダに保存できます（ユーザーのWindows側でのみ実行可能）。
- **C#の合成テストを追加**：100B重複2件＋80B独立ファイルで合計115Bを試算、二重計上10Bを削除する契約を試験予定。
- **独立Python参考テスト**：数学的な集計仕様を合成データで検査（C#実行試験ではありません）。

**動作状況：** こちらの作業環境に.NET SDKとWindowsがないため、R2.1のC#ビルド・実行テストは未実施です。現時点でもハードリンク統合、原本置換、自動削除は通常版で停止しています。候補の作成はむしろ空き容量を消費します。**本番の写真・動画を変更・処理しないでください。**

### Windowsでの診断

1. ZIPを解凍し、Windowsに **.NET 10 SDK** を導入。
2. `RUN_DIAGNOSTICS.bat` を実行（隔離された合成ファイルだけでテストします）。
3. `diagnostics/RESULT.txt` と関連ログのPASS/FAILを確認。PASSになっても実データ適用はまだ禁止です。
4. `docs/ROADMAP_STATUS.md` と `docs/R21_TEST_PLAN.md` を参照。

---

## R2.0以前からの機能（引き継ぎ）

### R2.0 — PNG/JPG統合容量レポート・JPG進捗ログ復旧

## R2.0で追加したもの（2026-11-14）

- **PNG/JPG候補の横断容量レポート**：同じ原本フォルダ・候補保存先にある両方の一括処理記録を読み取り、ファイルごとの候補サイズ・削減見込・要確認を集約。どちらか片方の計画しかなくても動作可能。
- **「候補上の削減見込」と「実際の回復容量」の完全分離**：R2.0は原本を書き換えないため、実際の回復容量は常に **0 B** として報告。重複排除の理論削減量とは単純加算しない。
- **JPGログ末尾診断・明示修復**：不完全JSON末尾の除外、正常JSON末尾への改行追加。修復前ログ全体を別名バックアップに保存。中間破損・計画外レコードは修復拒否。
- **JPGログの逐次検証**：後続の正常行で途中の不正状態が隠れないよう各行の状態・候補パス・ハッシュを検証。
- **Windows用テストコードを追加**：専用の合成画像だけで、PNG/JPG統合レポート・CSV注入対策・不完全ログ・手動修復・不正中間レコードを確認できるようにした。
- **原本置換の取引（トランザクション）設計書**：必要なテスト条件を明確化。**置換・データ削除コードはこの版では追加していない**。

操作は「親フォルダを指定 → PNG/JPGの一括候補を別フォルダに生成 → PNG/JPG統合容量レポート」から。JPGログが途中で切れた場合のみ「JPGログ末尾診断・復旧」を使用してね。

**注意:** JPG候補生成は `jpegtran.exe` が必要。統合レポートとログ修復は `jpegtran.exe` の実行なしに動作するよう設計した。候補生成時は新規ファイルを作るので、空き容量がゼロなら利用できない。実データでの安全試験を終えるまで必ずテスト用コピーだけを指定すること。


**Windows 10/11 / .NET 10 / WPF・C# / 実機未検証のソース試験版**

> **原本を変更する機能は引き続き停止しています。** JPG/PNGの完全無劣化最適化は別フォルダに候補を追加するのみ。**現在のディスク空き容量は増えません**。本番の写真・動画への適用は禁止。テスト用コピーだけを使用してください。R2.0のC#コードはWindows上でビルド・実行未確認です。

## 今回の追加内容

1. `Core/JpegBatchPreviewEngine.cs` — JPG/JPEGを親フォルダから再帰列挙、**小さい順**に `jpegtran.exe -copy all -optimize` で候補を作成。候補は必ず `chappy-jpeg-r19-previews` 以下に作成し、原本には一切書き込まない。
2. **ジョブ再開** — 初回は `.chappy-jpeg-r19.plan.json` を新規作成。1ファイルの結果ごとに `.chappy-jpeg-r19.progress.jsonl` に追記・ディスクフラッシュ。中断後は同じ入力・出力・jpegtran.exeを指定して再開。完了済み候補をSHA-256とサイズ・更新日時で再検証する。
3. **破損ログで安全停止** — ログ末尾の不完全レコード、中間の破損、パス改ざんを検出した場合は自動で削除／修復しない。候補を勝手に片付けない。
4. **読み取り専用の容量見込監査** — 原本・候補の両方のSHA-256再照合に合格した候補だけを集計。CSVエクスポートは原本/出力候補フォルダ外に限定、既存CSVを上書きしない。CSV数式注入を防ぐ。
5. **GUIボタン追加** — 「JPGフォルダ一括プレビュー／再開」「JPG候補の容量レポート／CSV」。通常版のハードリンク統合は引き続き無効。
6. **Windowsテストコード** — 無効JPEG・ログ破損・再開・元ファイル変更・パス脱出・CSV書き込み拒否などを追加。

## Windowsでの安全な試し方（テスト用コピー限定）

1. 最新の .NET 10 SDK を導入し、`RUN_TESTS.bat` を実行。テストが失敗したら処理を続けない。
2. `BUILD_EXE.bat` を実行して `dist\win-x64\ChappyStorageCompressor.exe` を作成。
3. JPG候補には外部の `jpegtran.exe` が必要。公式 [libjpeg-turbo Releases](https://github.com/libjpeg-turbo/libjpeg-turbo/releases) からWindows向けを取得して指定する（ZIPには含めない）。信頼できる配布物のみ利用。
4. **テスト用** JPG/PNGを入れた親フォルダを選択。「JPGフォルダ一括プレビュー／再開」→`jpegtran.exe`→候補の保存先を指定。保存先は原本フォルダと独立させ、十分な空き容量を確保する。
5. 同じ入力・出力・ツールで操作すればログを再利用。中断は「中断要求」を押す。単一ファイルが終了するまで待機する場合がある。
6. 「JPG候補の容量レポート／CSV」で保存済み候補を再照合し、実ディスクの空き容量と混同しない。

## 現在の制限・安全ルール

- 形式：JPG/JPEGの8bitベースライン・単一スキャン・48MP/512MiB以内を中心とする。プログレッシブ等は無理に処理しない。外部ツールに依存する。
- `jpegtran` による量子化済み画素データの無劣化最適化であって、**元ファイルと候補のバイト列同一性ではない**。保護マーカーとWIC復号後RGB画素の比較に合格した候補のみ保存する。
- 再開キューは最大100,000件、JSONLは128MiB上限。入力と出力は親子関係不可。リンク/ジャンクション経由を除外。
- 空き容量が足りなくなると保留。出力先には少なくとも**元JPEGサイズ+16MiB**の空きが必要な場合がある。候補が増えるので満杯ディスクの直接救済にはならない。
- JPGの前処理、ログ出力などは部分書き込み状態になることがある。失敗時は証拠を残し、元ファイルは保護する。
- 同じJPGキューを並行実行しないよう出力先ロックを取得する。ログには機密性のある画像のファイルパスが含まれるため、共有・公開しない。
- **実際の容量回復 / 自動置換 / 実機での安全検証は未達成。** JPEG候補自体の整合確認もWindows実行テスト待ち。

## 検証状況

| 項目 | 状態 |
|---|---|
| Pythonの構造・XAML接続の静的チェック | このキットで実行 |
| Python JPEG参考6件 / PNG参考5件 | 以前の検証を引き継ぐ |
| C# Windowsビルドとテスト | **未実行** |
| JPEG一括処理のWindows外部ツール実測 | **未実行** |
| 原本置換によるディスク容量回復 | **未実装** |

詳細は `docs/ROADMAP_STATUS.md` と `docs/R19_TEST_PLAN.md` を参照。
