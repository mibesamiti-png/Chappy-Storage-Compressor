# R2.6 — 全体ロードマップと検証状況

更新：**2026-11-14**。本版は**Windowsでのビルド・実行未検証のC#ソース試作版**です。個人の写真・動画への適用は禁止。変更したのは `CHAPPY_TESTING` 限定の合成ファイル用置換実験で、通常版では原本置換と重複統合を有効化していません。

| 工程 | R2.5 | R2.6 | 状態 |
|---|---:|---:|---|
| R1 完全一致検出・基本ハードリンク統合 | 90% | **90%** | 実装済みだが本番統合ゲートは閉鎖 |
| R1.x 安全性・障害復旧 | 97% | **98%** | テスト専用の置換直前候補/バックアップ再検証とファイル同一性確認を追加 |
| R2 JPG/PNG完全無劣化プレビュー | 68% | **68%** | 原本を置換しない候補生成のみ |
| R3 統合解除・独立化 | 15% | **15%** | 完成したハードリンク統合を一般的に元に戻す機能は未完成 |
| R4 一括処理・分析・キュー | 76% | **76%** | 今回は本番機能の追加なし |

**全体ソース実装率の参考値： (90+98+68+15+76)/5 = 69.4%**（前回69.2%、+0.2ポイント）。これは**ソース機能量の主観的な見積もり**であり、実行できた割合・データ安全性・製品完成率ではありません。

**実行・実用化ゲート：Windowsビルド 0/1、Windows NTFS合成テスト 0/1、実データ運用許可 0/1。実際に回復させた容量：0 B。**

## R2.6で修正した欠陥

- **遅延した一時ファイルの改変を検出**：`Begin` の初期コピー検証後、`File.Replace` 直前にステージング済み候補とバックアップをもう一度SHA-256・サイズ・ファイルID・属性などで確認します。以前はこの直前再検証がなく、候補を改ざんされても置換まで進める可能性がありました。
- **照合途中のパス差し替えを検出**：`VerifyFile` で読込前のファイルID・メタデータ・リンク数を記録し、SHA-256計算後に再検証します。バイト列が完全一致でも異なる実体に差し替わった場合は拒否します。
- `tests/Program.cs` に末尾の候補改変、バックアップ改変、ハードリンク増加、同じSHA-256の別ファイルへの差し替えを模擬する合成テストを追加。**テストコードはWindows上で未実行**。
- `RUN_DIAGNOSTICS.bat` とWindows GitHub Actionsに新検証を追加。未接続のCIで実行成功したという意味ではありません。

## 今回の検証台帳

| 試験 | R2.6結果 | 示せること |
|---|---|---|
| 既存Python静的検査 | PASS | ソースの一定の形・参照 |
| 新しいソース契約検査 | **27/27 PASS** | 新しいC#コードの配置・ビルド分離・テスト配線の静的検査 |
| Python/POSIX独立参考検証 | **10/10 PASS** | ハッシュ一致と実体同一性の違いを再現した参考モデル |
| PNG・JPEGの既存参考検証 | **5/5、6/6 PASS** | Python上の独立参考検証 |
| Windows上の .NET 10 ビルド | **NOT RUN** | 開発環境にSDKとWindowsがなくコンパイル未検証 |
| Windows NTFSでのC#テスト | **NOT RUN** | OS API動作の実証なし |
| 原本置換・ディスク空き容量回復 | **DISABLED / 0 B** | 変更を伴う一般機能は引き続き使えない |

**限界：**事前・事後にファイルIDを確認しても、最後の照合後に第三者がパスを切り替える競合は消えません。安全な本番版には開いたハンドルとファイルIDを結び付けた操作、排他処理、別物理ドライブへの検証済みバックアップ、電源断復旧テストが必要です。

## 次の最優先ゲート R2.7

1. Windowsの.NET 10 SDK環境で `RUN_DIAGNOSTICS.bat` を実行し、**C#のコンパイル・テストで発見した不具合を修正**する。検証ログを `diagnostics/` から収集する。
2. 使い捨てNTFSテストファイルで復旧中の競合、メタデータ/ADS、ACL、電源断相当、ファイルID、空き容量の増減を検証する。
3. 原本を置換する処理を本番機能へ有効化するのは上記の検証合格後。画像の完全無劣化条件も別途証明する。

---

# R2.5 — Roadmap and verification ledger

Updated: **2026-11-14 JST**. Progress is a **subjective estimate of source-feature coverage** and must not be interpreted as reliable working software. This is a safe, test-only increment from R2.4.

| Workstream | R2.4 | R2.5 | Evidence |
|---|---:|---:|---|
| R1 duplicate detection / hardlink prototype | 90% | **90%** | Live deduplication remains disabled. |
| R1.x safety / crash journal / rollback | 96% | **97%** | Test-only artifacts now checked for hardlink count, unsafe attributes, ADS and journal size; C# smoke tests not run. |
| R2 lossless JPG/PNG previews | 68% | **68%** | Preview-only, original replacement still off. |
| R3 reverse successful dedupe / independent restore | 15% | **15%** | No new independent restored-file operation. |
| R4 queue / planning / reports | 76% | **76%** | No production-facing change. |

**Source-feature average: (90+97+68+15+76)/5 = 69.2%**, up from R2.4 **69.0% (+0.2 percentage points)**. This is not tested success. Actual recovered space **0 B**. Windows build **NOT RUN**; Windows C# NTFS smoke tests **NOT RUN**.

## R2.5 changes

1. `Core/SyntheticReplacementExperiment.cs`: added `RequireIndependentPlainFile`, used before hash checks on rollback and cleanup artifacts. Active and pending journals must be standalone regular files, 1..8192 bytes for active journal. Before cleanup of quarantine and external copy, repeat structure/content checks. This is still test-only and **not race free**.
2. `tests/Program.cs`: added `TestR25ArtifactIsolation` with hardlink-backup, hardlink-journal, hardlink-rollback, oversized journal, shared temporary journal, and named stream scenarios. Smoke runner refuses non-NTFS TEMP.
3. `.csproj`: added `EnableWindowsTargeting` for future cross-host compilation attempts. Not verified by compiler.
4. `tools/r25_contract_check.py` **25/25 PASS** and `tools/r25_reference_check.py` **10/10 PASS** (static/independent Python only).
5. `RUN_DIAGNOSTICS.bat`, CI workflow and ZIP builder updated to R2.5. No GitHub CI run or Windows publish is claimed.

## Next gates

- Run **Windows .NET 10** build + smoke tests and fix actual failures. This is the largest unresolved blocker and must not be replaced by more text-only checks.
- Test named streams, reparse points, changes to same-content hardlinks, power-loss interruptions and file replacement races using synthetic NTFS fixtures.
- Design identity-bound exclusive handles and atomic, independent-backup recovery before considering production file mutation.
- Measure *real* free-space changes on synthetic NTFS test volumes, and distinguish from theoretical candidate savings.
- Only after those gates, opt-in duplicate consolidation and lossless media replacement can be considered.

**Do not run against original media.**

---

# R2.4 — Overall roadmap and verification ledger

Updated: **2026-11-14 JST**. These percentages are **estimates of source-feature coverage only**, **not** tested reliability. All production original mutation and deduplication gates remain **closed**.

| Workstream | R2.3 | R2.4 | Assessment |
|---|---:|---:|---|
| R1 Exact-duplicate detection / hardlink prototype | 90% | 90% | No change; live merge still disabled. |
| R1.x Safety, crash journal, rollback | 95% | 96% | Added synthetic pre-journal orphan handling and post-journal cleanup; Windows integration not tested. |
| R2 Fully lossless JPEG/PNG preview | 68% | 68% | Previews only; no verified in-place disk recovery. |
| R3 Successful dedupe undo and independent restoration | 15% | 15% | Still distinct from interrupted-operation rollback. |
| R4 Batch processing, planning and analysis | 76% | 76% | Unchanged, no production batch behavior added. |

**Overall source-feature estimate: (90+96+68+15+76)/5 = 69.0%** (R2.3: 68.8%, +0.2 points). **Actual disk space recovered: 0 B. Windows build: NOT RUN. Windows NTFS test pass count: NOT RUN.**

## R2.4 implemented

1. `Core/SyntheticReplacementExperiment.cs`: test-only `InspectPreparation`/`DiscardVerifiedPreparation` and stronger rollback lifecycle. Refuses uncertain leftovers rather than blindly deleting. Fixes R2.3 gap where a pre-journal interruption could leave unresolvable staging files and where normal rollback left the external synthetic backup orphaned.
2. `tests/Program.cs`: tests pre-journal interruption at 3 checkpoints, a post-journal interrupted cleanup, retry after verified cleanup, tamper refusal, named-stream rejection, last-moment source changes, and full snapshot restoration after rollback.
3. `tools/r24_reference_check.py` and `tools/r24_contract_check.py`: Python independent state/reference model (13/13) and source-structure checks (25/25), **not C# tests**.
4. `RUN_DIAGNOSTICS.bat` and GitHub Actions: actionable build / smoke / publish logs, including failure uploads in CI.

## Remaining release gates (must pass before user media changes)

- Obtain **.NET 10 SDK / Windows NTFS**; compile R2.4 and execute the C# smoke suite. Fix any compiler/behavioral failures; do not accept Python static results as runtime proof.
- Repeat interrupted-transaction tests under concurrent write / sharing violations / shutdown and on separate physical backup media. Test ACL, created/modified timestamps, NTFS named streams, reparse points, directory rename race and source identity.
- Implement production-ready serialized transactions with durable independent backups, identity-bound handles, file-lock strategy, verified equivalence of media pixels/metadata, space reservations, precise recovery status and explicit opt-in confirmation.
- Validate automatic deduplication and independently reversible storage links only after passing the full release gate. Existing hardlink approach changes cross-path edit semantics.
- Record actual physical available-space changes and per-file savings on synthetic NTFS volumes; currently not proven.

**Do not run this prototype on personal original photos/videos.** Source code implementation coverage of 69.0% is not release readiness.

---

# Chappy Storage Compressor — R2.3 roadmap/status

Updated: 2026-11-14 JST. **All percentages are estimates of source implementation coverage**, not tested correctness or release readiness. The exact duplicate merge and original media replacement gates stay **DISABLED**; actual disk space recovered = **0 B**.

| Workstream | R2.2 | R2.3 | Assessment |
|---|---:|---:|---|
| R1 Exact duplicate detection & initial hardlink prototype | 90% | 90% | Windows/NTFS merge acceptance gate remains closed. |
| R1.x Safety, crash journal & recovery | 93% | 95% | Added test-only cutover/rollback state machine and 6 fault points, not yet compiled/executed on Windows. |
| R2 Fully lossless JPEG/PNG preview | 68% | 68% | Preview-only. No safe original replacement or broader production test coverage. |
| R3 Unlink / independent-file restore | 15% | 15% | Existing recovery wizard is not a general undo for successful dedupe. |
| R4 Batch scheduling, analysis & capacity preflight | 76% | 76% | No new production-facing features in R2.3. |

**Overall source-feature approximation: (90+95+68+15+76)/5 = 68.8%**, up from R2.2's 68.4% (+0.4 points). A deliberately small change: most of the work was test infrastructure, not a working storage recovery feature.

## Changes in R2.3

1. `Core/SyntheticReplacementExperiment.cs` is **completely compiled out of production** using `#if CHAPPY_TESTING`. It can only create and modify disposable synthetic files inside uniquely generated Windows TEMP test directories bearing a sentinel. There is no GUI / public release entry point.
2. Synthetic protocol: preflight, independent-copy simulation, SHA-256 checks, staged candidate, flushed JSON journal, Win32-backed `File.Replace` on synthetic files, and an interruption-aware rollback. A successful experiment still leaves a rollback journal until the test restores the original.
3. Windows smoke tests now exercise six interruption points (two prior to journaling, two during cutover, two during restoration), normal restoration of the exact file identity, tampered backup refusal, already hardlinked originals, active writer, and missing test-only sentinel.
4. Added cross-platform **reference-only** Python tests (7/7 PASS) plus source contract inspections (20/20 PASS). The old static checks and PNG/JPEG/combined/capacity reference checks remain available.
5. Updated CI workflow to execute reference checks before the Windows .NET build; note that this workflow has **not** been run against R2.3 in a GitHub repository here.

## Verification ledger

| Check | R2.3 result | Meaning |
|---|---|---|
| Existing Python structural suite | PASS; see `docs/R23_STATIC_VERIFY_RESULT.txt` | Source-text checks only |
| R2.3 structural contract | **20/20 PASS** | Build gating and test wiring only |
| R2.3 Python synthetic file-state reference | **7/7 PASS** | Python emulation, not Windows `File.Replace` |
| PNG/JPEG independent references | **5/5 and 6/6 PASS** | Format reference checks |
| Non-overlap and capacity reference checks | **4/4 and 10/10 PASS** | Python formula checks |
| R2.3 C# Windows WPF build | **NOT RUN** | .NET SDK absent; internet unavailable |
| R2.3 C# NTFS smoke tests | **NOT RUN** | Await Windows execution |
| Real media replacement | **DISABLED** | 0 B actually recovered |
| Physical power-loss / ACL / writer-race | **NOT VERIFIED** | Production release blockers |

## Next: R2.4 release gates

1. Run `RUN_DIAGNOSTICS.bat` on Windows and fix any actual C# compiler or test failures.
2. Extend isolated test matrix to same-drive vs external-drive staging, ACL and timestamps, current writer concurrency, named streams, path rename races, multiple volumes, and power-failure recovery.
3. Design release-grade backup verification, image equivalence gating and opt-in confirmation separately. Keep the source locked until these gates are proven.
4. Only then prototype actual volume free-space measurements and resource-limited sequential recovery on synthetic data.

---

# Chappy Storage Compressor — R2.2 roadmap/status

Updated: 2026-11-14 JST.

**Progress percentages are subjective estimates of source-feature coverage, NOT working-product quality, test pass rate, or proof of safety.** Original file replacement and live deduplication are still DISABLED. Freed disk bytes: **0 B**.

| Workstream | R2.1 | R2.2 | Evidence / remaining work |
|---|---:|---:|---|
| R1 Exact duplicate scanning, initial hardlink engine | 90% | 90% | Implementation exists. Release merge gate still closed pending NTFS tests. |
| R1.x Safety, crash journal and restoration | 93% | 93% | No new crash-proof mutation. Windows and power-loss integration tests still pending. |
| R2 PNG/JPG fully lossless preview engine | 68% | 68% | Read-only candidates exist; no proven safe replacement or broad input compatibility. |
| R3 Undo dedupe / independent file restoration | 15% | 15% | Recovery wizard for interrupted operations is not an ordinary unlink-all function. |
| R4 Batch scheduling, analysis and capacity planning | 72% | 76% | Added read-only replacement preflight + GUI, capacity formula checks. |

**Overall source-feature approximation: (90+93+68+15+76)/5 = 68.4%.** Previous R2.1 67.6%; +0.8 percentage points. The smaller increase reflects a targeted safety improvement, not increased operational readiness.

## R2.2 implementation

- `Core/ReplacementReadiness.cs`: screening each verified preview row for: source still exists with expected size, safe NTFS file attributes, absence of alternate streams, single-link identity, output backup separation, and sufficient nominal space to stage the candidate and preserve one original copy.
- New WPF button `容量回復の事前安全診断` in `MainWindow.xaml`; select candidate-record output folder then separate backup folder to view pass/hold reasons.
- 64 MiB reserve on source and backup volumes, arithmetic without signed `long` overflow.
- Windows smoke-test additions for capacity edge cases; independent Python capacity reference 10/10 PASS.
- **No file-replacement or deduplication release-gate change.**

## Verification

| Check | R2.2 status |
|---|---|
| Python structural/GUI/source safety checks | See `docs/R22_STATIC_VERIFY_RESULT.txt`; static only |
| PNG independent reference checks | 5/5 PASS |
| JPEG independent reference checks | 6/6 PASS |
| Combined savings independent reference checks | 4/4 PASS |
| R2.2 capacity formula reference | 10/10 PASS |
| Windows C# build | **Not run**: no .NET SDK/Windows in current environment |
| Windows C# smoke tests | **Not run** |
| Actual original replacement / free-space recovery | **Not implemented: 0 B** |

## R2.3 priorities

1. Get Windows build + C# smoke-tests running; fix errors rather than adding new unverified features.
2. Use isolated NTFS synthetic volumes to test inode/file ID, named streams, journals, concurrency and crash recovery.
3. Prototype backup-first replacement **behind a test-only build gate** and prove rollback at each step. Do not enable on users' originals.
4. Verify that an independent backup device and a same-volume staging area exist; low-space modes may be forced to stop.
5. Only after repeated green tests, design opt-in release and actual before/after volume free-space measurement.
